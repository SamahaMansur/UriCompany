class CreateDailyReturneds < ActiveRecord::Migration[5.1]
  def change
    create_table :daily_returneds do |t|
      t.string :Product_name
      t.string :Category
      t.float :Unit_price
      t.float :Selling_price
      t.integer :Quantity
      t.date :Date

      t.timestamps
    end
  end
end
