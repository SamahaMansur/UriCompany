class CreateSuppliers < ActiveRecord::Migration[5.1]
  def change
    create_table :suppliers do |t|
      t.string :Supplier_name
      t.string :Supplier_code
      t.string :Email_address
      t.string :Contact_number
      t.string :Location

      t.timestamps
    end
  end
end
