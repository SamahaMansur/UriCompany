class CreateStocks < ActiveRecord::Migration[5.1]
  def change
    create_table :stocks do |t|
      t.string :Product_name
      t.string :Product_id
      t.string :Category
      t.float :Unit_price
      t.float :Selling_price
      t.float :Vat
      t.integer :Quantity
      t.date :Date

      t.timestamps
    end
  end
end
