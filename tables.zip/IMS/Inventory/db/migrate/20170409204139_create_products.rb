class CreateProducts < ActiveRecord::Migration[5.1]
  def change
    create_table :products do |t|
      t.string :Product_name
      t.string :Product_Id
      t.string :Category
      t.float :Unit_Price
      t.float :Selling_Price
      t.float :Vat
      t.integer :Quantity
      t.date :Date

      t.timestamps
    end
  end
end
