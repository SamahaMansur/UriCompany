class CreatePurchases < ActiveRecord::Migration[5.1]
  def change
    create_table :purchases do |t|
      t.string :Product_name
      t.string :Category
      t.float :Unit_price
      t.integer :Quantity
      t.string :Supplier_name
      t.string :Supplier_code
      t.string :Location
      t.date :Date

      t.timestamps
    end
  end
end
