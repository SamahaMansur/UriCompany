class CreateDailyDamageds < ActiveRecord::Migration[5.1]
  def change
    create_table :daily_damageds do |t|
      t.string :name
      t.string :category
      t.float :unit_price
      t.float :selling_price
      t.float :vat
      t.integer :quantity

      t.timestamps
    end
  end
end
