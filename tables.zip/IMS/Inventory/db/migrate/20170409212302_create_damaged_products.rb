class CreateDamagedProducts < ActiveRecord::Migration[5.1]
  def change
    create_table :damaged_products do |t|
      t.string :Product_name
      t.string :Category
      t.float :Unit_price
      t.float :Selling_price
      t.integer :Quantity
      t.date :Date

      t.timestamps
    end
  end
end
