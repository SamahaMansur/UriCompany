module DailySoldsHelper
end
