class Supplier < ApplicationRecord
end
