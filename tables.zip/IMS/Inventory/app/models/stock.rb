class Stock < ApplicationRecord
end
