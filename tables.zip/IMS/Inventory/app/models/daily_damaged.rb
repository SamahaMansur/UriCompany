class DailyDamaged < ApplicationRecord
end
