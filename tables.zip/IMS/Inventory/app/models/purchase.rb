class Purchase < ApplicationRecord
end
