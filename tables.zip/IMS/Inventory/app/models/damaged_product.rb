class DamagedProduct < ApplicationRecord
end
