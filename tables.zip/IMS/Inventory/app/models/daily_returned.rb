class DailyReturned < ApplicationRecord
end
