class DailySold < ApplicationRecord
end
