class DamagedProductsController < ApplicationController
  before_action :set_damaged_product, only: [:show, :edit, :update, :destroy]

  # GET /damaged_products
  # GET /damaged_products.json
  def index
    @damaged_products = DamagedProduct.all
  end

  # GET /damaged_products/1
  # GET /damaged_products/1.json
  def show
  end

  # GET /damaged_products/new
  def new
    @damaged_product = DamagedProduct.new
  end

  # GET /damaged_products/1/edit
  def edit
  end

  # POST /damaged_products
  # POST /damaged_products.json
  def create
    @damaged_product = DamagedProduct.new(damaged_product_params)

    respond_to do |format|
      if @damaged_product.save
        format.html { redirect_to @damaged_product, notice: 'Damaged product was successfully created.' }
        format.json { render :show, status: :created, location: @damaged_product }
      else
        format.html { render :new }
        format.json { render json: @damaged_product.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /damaged_products/1
  # PATCH/PUT /damaged_products/1.json
  def update
    respond_to do |format|
      if @damaged_product.update(damaged_product_params)
        format.html { redirect_to @damaged_product, notice: 'Damaged product was successfully updated.' }
        format.json { render :show, status: :ok, location: @damaged_product }
      else
        format.html { render :edit }
        format.json { render json: @damaged_product.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /damaged_products/1
  # DELETE /damaged_products/1.json
  def destroy
    @damaged_product.destroy
    respond_to do |format|
      format.html { redirect_to damaged_products_url, notice: 'Damaged product was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_damaged_product
      @damaged_product = DamagedProduct.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def damaged_product_params
      params.require(:damaged_product).permit(:Product_name, :Category, :Unit_price, :Selling_price, :Quantity, :Date)
    end
end
