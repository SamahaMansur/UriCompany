class DailyReturnedsController < ApplicationController
  before_action :set_daily_returned, only: [:show, :edit, :update, :destroy]

  # GET /daily_returneds
  # GET /daily_returneds.json
  def index
    @daily_returneds = DailyReturned.all
  end

  # GET /daily_returneds/1
  # GET /daily_returneds/1.json
  def show
  end

  # GET /daily_returneds/new
  def new
    @daily_returned = DailyReturned.new
  end

  # GET /daily_returneds/1/edit
  def edit
  end

  # POST /daily_returneds
  # POST /daily_returneds.json
  def create
    @daily_returned = DailyReturned.new(daily_returned_params)

    respond_to do |format|
      if @daily_returned.save
        format.html { redirect_to @daily_returned, notice: 'Daily returned was successfully created.' }
        format.json { render :show, status: :created, location: @daily_returned }
      else
        format.html { render :new }
        format.json { render json: @daily_returned.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /daily_returneds/1
  # PATCH/PUT /daily_returneds/1.json
  def update
    respond_to do |format|
      if @daily_returned.update(daily_returned_params)
        format.html { redirect_to @daily_returned, notice: 'Daily returned was successfully updated.' }
        format.json { render :show, status: :ok, location: @daily_returned }
      else
        format.html { render :edit }
        format.json { render json: @daily_returned.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /daily_returneds/1
  # DELETE /daily_returneds/1.json
  def destroy
    @daily_returned.destroy
    respond_to do |format|
      format.html { redirect_to daily_returneds_url, notice: 'Daily returned was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_daily_returned
      @daily_returned = DailyReturned.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def daily_returned_params
      params.require(:daily_returned).permit(:Product_name, :Category, :Unit_price, :Selling_price, :Quantity, :Date)
    end
end
