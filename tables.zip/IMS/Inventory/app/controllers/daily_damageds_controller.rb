class DailyDamagedsController < ApplicationController
  before_action :set_daily_damaged, only: [:show, :edit, :update, :destroy]

  # GET /daily_damageds
  # GET /daily_damageds.json
  def index
    @daily_damageds = DailyDamaged.all
  end

  # GET /daily_damageds/1
  # GET /daily_damageds/1.json
  def show
  end

  # GET /daily_damageds/new
  def new
    @daily_damaged = DailyDamaged.new
  end

  # GET /daily_damageds/1/edit
  def edit
  end

  # POST /daily_damageds
  # POST /daily_damageds.json
  def create
    @daily_damaged = DailyDamaged.new(daily_damaged_params)

    respond_to do |format|
      if @daily_damaged.save
        format.html { redirect_to @daily_damaged, notice: 'Daily damaged was successfully created.' }
        format.json { render :show, status: :created, location: @daily_damaged }
      else
        format.html { render :new }
        format.json { render json: @daily_damaged.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /daily_damageds/1
  # PATCH/PUT /daily_damageds/1.json
  def update
    respond_to do |format|
      if @daily_damaged.update(daily_damaged_params)
        format.html { redirect_to @daily_damaged, notice: 'Daily damaged was successfully updated.' }
        format.json { render :show, status: :ok, location: @daily_damaged }
      else
        format.html { render :edit }
        format.json { render json: @daily_damaged.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /daily_damageds/1
  # DELETE /daily_damageds/1.json
  def destroy
    @daily_damaged.destroy
    respond_to do |format|
      format.html { redirect_to daily_damageds_url, notice: 'Daily damaged was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_daily_damaged
      @daily_damaged = DailyDamaged.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def daily_damaged_params
      params.require(:daily_damaged).permit(:name, :category, :unit_price, :selling_price, :vat, :quantity)
    end
end
