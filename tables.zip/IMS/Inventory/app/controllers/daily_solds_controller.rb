class DailySoldsController < ApplicationController
  before_action :set_daily_sold, only: [:show, :edit, :update, :destroy]

  # GET /daily_solds
  # GET /daily_solds.json
  def index
    @daily_solds = DailySold.all
  end

  # GET /daily_solds/1
  # GET /daily_solds/1.json
  def show
  end

  # GET /daily_solds/new
  def new
    @daily_sold = DailySold.new
  end

  # GET /daily_solds/1/edit
  def edit
  end

  # POST /daily_solds
  # POST /daily_solds.json
  def create
    @daily_sold = DailySold.new(daily_sold_params)

    respond_to do |format|
      if @daily_sold.save
        format.html { redirect_to @daily_sold, notice: 'Daily sold was successfully created.' }
        format.json { render :show, status: :created, location: @daily_sold }
      else
        format.html { render :new }
        format.json { render json: @daily_sold.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /daily_solds/1
  # PATCH/PUT /daily_solds/1.json
  def update
    respond_to do |format|
      if @daily_sold.update(daily_sold_params)
        format.html { redirect_to @daily_sold, notice: 'Daily sold was successfully updated.' }
        format.json { render :show, status: :ok, location: @daily_sold }
      else
        format.html { render :edit }
        format.json { render json: @daily_sold.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /daily_solds/1
  # DELETE /daily_solds/1.json
  def destroy
    @daily_sold.destroy
    respond_to do |format|
      format.html { redirect_to daily_solds_url, notice: 'Daily sold was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_daily_sold
      @daily_sold = DailySold.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def daily_sold_params
      params.require(:daily_sold).permit(:name, :category, :unit_price, :selling_price, :vat, :quantity)
    end
end
