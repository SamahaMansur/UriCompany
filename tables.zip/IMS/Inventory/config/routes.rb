Rails.application.routes.draw do
  devise_for :users
  resources :suppliers
  resources :damaged_products
  resources :daily_returneds
  resources :payments
  resources :purchases
  resources :stocks
  resources :products
  resources :product_lists
  resources :daily_damageds
  resources :daily_solds
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html

  root 'posts#user'
end
