require 'test_helper'

class ProductListTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
