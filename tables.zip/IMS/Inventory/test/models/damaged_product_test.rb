require 'test_helper'

class DamagedProductTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
