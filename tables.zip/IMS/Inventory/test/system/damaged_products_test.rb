require "application_system_test_case"

class DamagedProductsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit damaged_products_url
  #
  #   assert_selector "h1", text: "DamagedProduct"
  # end
end
