require "application_system_test_case"

class DailyDamagedsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit daily_damageds_url
  #
  #   assert_selector "h1", text: "DailyDamaged"
  # end
end
