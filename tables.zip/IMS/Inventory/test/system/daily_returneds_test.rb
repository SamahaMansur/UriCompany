require "application_system_test_case"

class DailyReturnedsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit daily_returneds_url
  #
  #   assert_selector "h1", text: "DailyReturned"
  # end
end
