require "application_system_test_case"

class ProductListsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit product_lists_url
  #
  #   assert_selector "h1", text: "ProductList"
  # end
end
