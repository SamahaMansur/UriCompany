require "application_system_test_case"

class SuppliersTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit suppliers_url
  #
  #   assert_selector "h1", text: "Supplier"
  # end
end
