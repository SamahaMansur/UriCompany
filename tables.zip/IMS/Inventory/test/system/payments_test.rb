require "application_system_test_case"

class PaymentsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit payments_url
  #
  #   assert_selector "h1", text: "Payment"
  # end
end
