require 'test_helper'

class DamagedProductsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @damaged_product = damaged_products(:one)
  end

  test "should get index" do
    get damaged_products_url
    assert_response :success
  end

  test "should get new" do
    get new_damaged_product_url
    assert_response :success
  end

  test "should create damaged_product" do
    assert_difference('DamagedProduct.count') do
      post damaged_products_url, params: { damaged_product: { Category: @damaged_product.Category, Date: @damaged_product.Date, Product_name: @damaged_product.Product_name, Quantity: @damaged_product.Quantity, Selling_price: @damaged_product.Selling_price, Unit_price: @damaged_product.Unit_price } }
    end

    assert_redirected_to damaged_product_url(DamagedProduct.last)
  end

  test "should show damaged_product" do
    get damaged_product_url(@damaged_product)
    assert_response :success
  end

  test "should get edit" do
    get edit_damaged_product_url(@damaged_product)
    assert_response :success
  end

  test "should update damaged_product" do
    patch damaged_product_url(@damaged_product), params: { damaged_product: { Category: @damaged_product.Category, Date: @damaged_product.Date, Product_name: @damaged_product.Product_name, Quantity: @damaged_product.Quantity, Selling_price: @damaged_product.Selling_price, Unit_price: @damaged_product.Unit_price } }
    assert_redirected_to damaged_product_url(@damaged_product)
  end

  test "should destroy damaged_product" do
    assert_difference('DamagedProduct.count', -1) do
      delete damaged_product_url(@damaged_product)
    end

    assert_redirected_to damaged_products_url
  end
end
