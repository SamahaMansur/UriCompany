require 'test_helper'

class DailySoldsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @daily_sold = daily_solds(:one)
  end

  test "should get index" do
    get daily_solds_url
    assert_response :success
  end

  test "should get new" do
    get new_daily_sold_url
    assert_response :success
  end

  test "should create daily_sold" do
    assert_difference('DailySold.count') do
      post daily_solds_url, params: { daily_sold: { category: @daily_sold.category, name: @daily_sold.name, quantity: @daily_sold.quantity, selling_price: @daily_sold.selling_price, unit_price: @daily_sold.unit_price, vat: @daily_sold.vat } }
    end

    assert_redirected_to daily_sold_url(DailySold.last)
  end

  test "should show daily_sold" do
    get daily_sold_url(@daily_sold)
    assert_response :success
  end

  test "should get edit" do
    get edit_daily_sold_url(@daily_sold)
    assert_response :success
  end

  test "should update daily_sold" do
    patch daily_sold_url(@daily_sold), params: { daily_sold: { category: @daily_sold.category, name: @daily_sold.name, quantity: @daily_sold.quantity, selling_price: @daily_sold.selling_price, unit_price: @daily_sold.unit_price, vat: @daily_sold.vat } }
    assert_redirected_to daily_sold_url(@daily_sold)
  end

  test "should destroy daily_sold" do
    assert_difference('DailySold.count', -1) do
      delete daily_sold_url(@daily_sold)
    end

    assert_redirected_to daily_solds_url
  end
end
