require 'test_helper'

class DailyReturnedsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @daily_returned = daily_returneds(:one)
  end

  test "should get index" do
    get daily_returneds_url
    assert_response :success
  end

  test "should get new" do
    get new_daily_returned_url
    assert_response :success
  end

  test "should create daily_returned" do
    assert_difference('DailyReturned.count') do
      post daily_returneds_url, params: { daily_returned: { Category: @daily_returned.Category, Date: @daily_returned.Date, Product_name: @daily_returned.Product_name, Quantity: @daily_returned.Quantity, Selling_price: @daily_returned.Selling_price, Unit_price: @daily_returned.Unit_price } }
    end

    assert_redirected_to daily_returned_url(DailyReturned.last)
  end

  test "should show daily_returned" do
    get daily_returned_url(@daily_returned)
    assert_response :success
  end

  test "should get edit" do
    get edit_daily_returned_url(@daily_returned)
    assert_response :success
  end

  test "should update daily_returned" do
    patch daily_returned_url(@daily_returned), params: { daily_returned: { Category: @daily_returned.Category, Date: @daily_returned.Date, Product_name: @daily_returned.Product_name, Quantity: @daily_returned.Quantity, Selling_price: @daily_returned.Selling_price, Unit_price: @daily_returned.Unit_price } }
    assert_redirected_to daily_returned_url(@daily_returned)
  end

  test "should destroy daily_returned" do
    assert_difference('DailyReturned.count', -1) do
      delete daily_returned_url(@daily_returned)
    end

    assert_redirected_to daily_returneds_url
  end
end
