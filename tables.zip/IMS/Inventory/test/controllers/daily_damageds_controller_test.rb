require 'test_helper'

class DailyDamagedsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @daily_damaged = daily_damageds(:one)
  end

  test "should get index" do
    get daily_damageds_url
    assert_response :success
  end

  test "should get new" do
    get new_daily_damaged_url
    assert_response :success
  end

  test "should create daily_damaged" do
    assert_difference('DailyDamaged.count') do
      post daily_damageds_url, params: { daily_damaged: { category: @daily_damaged.category, name: @daily_damaged.name, quantity: @daily_damaged.quantity, selling_price: @daily_damaged.selling_price, unit_price: @daily_damaged.unit_price, vat: @daily_damaged.vat } }
    end

    assert_redirected_to daily_damaged_url(DailyDamaged.last)
  end

  test "should show daily_damaged" do
    get daily_damaged_url(@daily_damaged)
    assert_response :success
  end

  test "should get edit" do
    get edit_daily_damaged_url(@daily_damaged)
    assert_response :success
  end

  test "should update daily_damaged" do
    patch daily_damaged_url(@daily_damaged), params: { daily_damaged: { category: @daily_damaged.category, name: @daily_damaged.name, quantity: @daily_damaged.quantity, selling_price: @daily_damaged.selling_price, unit_price: @daily_damaged.unit_price, vat: @daily_damaged.vat } }
    assert_redirected_to daily_damaged_url(@daily_damaged)
  end

  test "should destroy daily_damaged" do
    assert_difference('DailyDamaged.count', -1) do
      delete daily_damaged_url(@daily_damaged)
    end

    assert_redirected_to daily_damageds_url
  end
end
